from distutils.core import setup
setup(
name='mxwg_sale_pay',
version='1.0.0',
py_modules=['mxwg'],
author='herotan',
author_email='herotan@qq.com',
description='sale and pay for MengXiangWangGuo'
)
